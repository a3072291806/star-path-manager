extends Control

const BG := Color("#17152F")
const PANEL := Color("#292344")
const PINK := Color("#E8B9F5")
const LAVENDER := Color("#C9A7FF")
const WHITE := Color("#FFF5FC")

func _ready() -> void:
	_build_screen()

func _build_screen() -> void:
	var background := ColorRect.new()
	background.color = BG
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var stars := Control.new()
	stars.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(stars)
	for i in range(65):
		var dot := ColorRect.new()
		dot.color = Color(WHITE, randf_range(0.25, 0.9))
		dot.position = Vector2(randf_range(12.0, 708.0), randf_range(20.0, 1260.0))
		dot.size = Vector2.ONE * randf_range(1.0, 3.0)
		stars.add_child(dot)

	var content := VBoxContainer.new()
	content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	content.offset_left = 38
	content.offset_top = 110
	content.offset_right = -38
	content.offset_bottom = -100
	content.add_theme_constant_override("separation", 26)
	content.alignment = BoxContainer.ALIGNMENT_CENTER
	add_child(content)

	var spacer_top := Control.new()
	spacer_top.custom_minimum_size.y = 80
	content.add_child(spacer_top)

	var title := Label.new()
	title.text = "星途经纪人"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size",  sixty())
	title.add_theme_color_override("font_color", PINK)
	content.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "STAR PATH  ·  IDOL MANAGEMENT"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 19)
	subtitle.add_theme_color_override("font_color", LAVENDER)
	content.add_child(subtitle)

	var spacer_mid := Control.new()
	spacer_mid.custom_minimum_size.y = 110
	content.add_child(spacer_mid)

	var start_button := _make_button("开始旅程")
	start_button.pressed.connect(_on_start_pressed)
	content.add_child(start_button)

	var continue_button := _make_button("继续游戏")
	continue_button.pressed.connect(_on_continue_pressed)
	content.add_child(continue_button)

	var footer := Label.new()
	footer.text = "梦想，从这里启程"
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	footer.add_theme_font_size_override("font_size", 20)
	footer.add_theme_color_override("font_color", Color("#D8C7F0"))
	content.add_child(footer)

func sixty() -> int:
	return 60

func _make_button(caption: String) -> Button:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = Vector2(0, 76)
	button.add_theme_font_size_override("font_size", 28)
	button.add_theme_color_override("font_color", WHITE)
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color("#8065C5")
	normal.border_color = Color("#E8CFFF")
	normal.set_border_width_all(2)
	normal.set_corner_radius_all(24)
	button.add_theme_stylebox_override("normal", normal)
	var hover := normal.duplicate()
	hover.bg_color = Color("#9B7BEA")
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", hover)
	return button

func _on_start_pressed() -> void:
	_show_message("欢迎来到星途经纪人！下一阶段将开启公司大厅。")

func _on_continue_pressed() -> void:
	_show_message("存档系统将在后续版本加入。")

func _show_message(message: String) -> void:
	var dialog := AcceptDialog.new()
	dialog.dialog_text = message
	add_child(dialog)
	dialog.popup_centered()
